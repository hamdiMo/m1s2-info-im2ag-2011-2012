/*
 * sphere.c : affichage de sphere
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <GL/glut.h>

GLenum doubleBuffer=GL_FALSE;
GLint width,height;
double Xrot=0, Yrot=0, Xtrans=0, Ytrans=0;


void DrawSphere(double R, int numc, int numt)
{
 
  
  glPushMatrix();
  glTranslatef(Xtrans, -Ytrans, 0);
  glRotatef(Yrot*180.0/M_PI , 0.0, -1.0, 0.0);
  glRotatef(Xrot*180.0/M_PI , 1.0, 0.0, 0.0);
  glutSolidSphere(1.0,20,20);
  glPopMatrix();
  

  /*
   * A COMPLETER
   */


  glFlush();
  if (doubleBuffer) {
    glutSwapBuffers();
  }
  
}

int beginx, beginy, moving = 0, translating = 0;
/* Fonction de gestion de l'evenement click d'un bouton de la souris */
void mouse(int button, int state, int x, int y)
{
 
  if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN) {
    moving = 1;
    beginx = x;
    beginy = y;
  }
  if (button == GLUT_LEFT_BUTTON && state == GLUT_UP) {
    moving = 0;
  }
  if (button == GLUT_MIDDLE_BUTTON && state == GLUT_DOWN) {
    translating = 1;
    beginx = x;
    beginy = y;
  }
  if (button == GLUT_MIDDLE_BUTTON && state == GLUT_UP) {
    translating = 0;
  }
}
 
/* Fonction de gestion de l'evenement deplacement de la souris */
void mouseMotion(int x, int y)
{
  if (moving) {
    Xrot = Xrot + (double)(y - beginy) * 10 / height;
    Yrot = Yrot - (double)(x - beginx) * 10 / width;
    beginx = x;
    beginy = y;
    glutPostRedisplay();
   }
  if (translating) {
    Xtrans = Xtrans + ((double)(x - beginx))/10;
    Ytrans = Ytrans + ((double)(y - beginy))/10;
    beginx = x;
    beginy = y;
    glutPostRedisplay();
  }
}


/* Mise a jour des variables de tailles de fenetre*/
void set_screen_wh(GLsizei w, GLsizei h)
{
        width=w;
        height=h;
}


void Reshape(int w, int h)
{
  
  glViewport(0, 0, w, h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  gluPerspective(45, (float) w/ (float)h, 0.1, 100.0);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glTranslatef(0,0,-5.0 );
  set_screen_wh(w,h);
  glutPostRedisplay();
}


void display()
{

  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  DrawSphere(1.0, 30,30);
}

void Key(unsigned char key, int x, int y)
{

    switch (key) {
      case 27:
	exit(1);
    }
}


/* rendu : definitions */
void init_rendu()
{
 
 /* 
  * A COMPLETER
  */ 

 
}
/*  Main Loop
 *  Ouverture de la fenetre d'affichage de tailles et titre donnes 
 *  et definition des fonctions de gestion d'evenement.
 */
int main(int argc, char **argv)
{
    GLenum type;

    glutInit(&argc, argv);
    glutInitWindowPosition(0, 0); 
    glutInitWindowSize( 500, 400);

    type = GLUT_RGB;
    type |= (doubleBuffer) ? GLUT_DOUBLE : GLUT_SINGLE;
    glutInitDisplayMode(type | GLUT_DEPTH);
 

 
   if (glutCreateWindow("Sphere") == GL_FALSE) {
        exit(1);
    }
  
  
   glEnable(GL_DEPTH_TEST);

   init_rendu();
  
   glClearColor (0.0, 0.4, 0.4, 0.0);
   glutMouseFunc(mouse);
   glutMotionFunc(mouseMotion);
   glutReshapeFunc(Reshape);
   glutKeyboardFunc(Key);
   glutDisplayFunc(display);
   glutMainLoop();
   return 0;
}

