package utils;

/**
 * Rassemble les constantes de l'application
 * @author fauvet
 *
 */
public class Constantes {
	public static final String Menu =
		"Bienvenue - Theatre - Gestion des categories " + "\n";
	
	public static final String Invite = "Votre choix" ;
	
	public static final String Config = "connection.conf";
	
}
