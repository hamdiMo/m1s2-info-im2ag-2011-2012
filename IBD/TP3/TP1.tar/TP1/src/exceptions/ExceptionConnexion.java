package exceptions;

public class ExceptionConnexion extends ExceptionTheatre {

	public ExceptionConnexion() {
		// TODO Auto-generated constructor stub
	}

	public ExceptionConnexion(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ExceptionConnexion(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public ExceptionConnexion(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
