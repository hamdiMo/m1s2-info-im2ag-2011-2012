/*
 * cube.c : projection image d'un cube
 * 
 * E.B. 
 */


#include <GL/glut.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

GLdouble Xrot, Yrot, Xtrans, Ytrans;

/* Fonction de Dessin */
void display()
{
  glClear( GL_COLOR_BUFFER_BIT);
  glPushMatrix();
  /* deplacement souris */
  glTranslatef(Xtrans,-Ytrans,0);

  glBegin(GL_LINE_LOOP);
  glVertex3f(-100,-100,100);
  glVertex3f(100,-100,100);
  glVertex3f(100,100,100);
  glVertex3f(-100,100,100);
  glEnd();

  glPopMatrix();
  glFlush();
    
}

int beginx, beginy, moving = 0, translating = 0;

/* Fonction de gestion de l'evenement click d'un bouton de la souris */
void mouse(int button, int state, int x, int y)
{
 
  if (button == GLUT_MIDDLE_BUTTON && state == GLUT_DOWN) {
    translating = 1;
    beginx = x;
    beginy = y;
  }
  if (button == GLUT_MIDDLE_BUTTON && state == GLUT_UP) {
    translating = 0;
  }
}
 
/* Fonction de gestion de l'evenement deplacement de la souris */
void mouseMotion(int x, int y)
{

  if (translating) {
    Xtrans = Xtrans + (double)(x - beginx);
    Ytrans = Ytrans + (double)(y - beginy);
    beginx = x;
    beginy = y;
    display();
  }
}


/* Fonction de test de touche du clavier */
static void key( unsigned char key, int x, int y )
{
  switch (key) {
  case 27:               /* sortie si ESC */
    exit(0);
  }
}


 
/* Fonction de reaffichage */
static void reshape(GLsizei w, GLsizei h)
{
  glViewport(0, 0, w, h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glOrtho(-200.0, 200.0, -200.0 , 200, -200.0, 200.0);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
}


/*  Main Loop
 *  Ouverture de la fenetre d'affichage de tailles et titre donnes 
 *  et definition des fonctions de gestion d'evenement.
 */
int main(int argc, char** argv)
{
  glutInit(&argc, argv);
  glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
  glutInitWindowSize (400, 400);
  glutCreateWindow ("cube");
  
  glClearColor (0.4, 0.4, 0.4, 0.0);
  glutMouseFunc(mouse);
  glutMotionFunc(mouseMotion);
  glutKeyboardFunc(key);
  glutDisplayFunc(display);
  glutReshapeFunc(reshape);
  glutMainLoop();
  return 0;
}
